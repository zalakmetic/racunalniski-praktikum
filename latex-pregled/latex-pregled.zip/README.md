# Pregledne datoteke za LaTeX

Avtor: Andrej Bauer

V arhivu jih študentje dobijo pri prvih vajah za LaTeX.